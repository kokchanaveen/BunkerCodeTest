import { Injectable } from '@angular/core';
import { Http, Response, Request,RequestOptions,Headers } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { IPeople } from './ipeople';


@Injectable()
export class PeopleService{

private _serviceUrl = 'assets/people.json';

 constructor(private _http: Http) { 

 }

 addPeople(objPeople:IPeople):Observable<IPeople>
 {
     let requestHeaders=new Headers({'Content-Type':'application/json'});
     let options=new RequestOptions({headers:requestHeaders});
     var x=JSON.stringify(objPeople);
     return this._http.post(this._serviceUrl,x,options).map(this.mapResponse).catch(this.handleError);
 }

 getPeople():Observable<IPeople>
 {
     return this._http.get(this._serviceUrl).
     map((response:Response)=><IPeople>response.json()) 
     .do(data=>console.log("All:"+ JSON.stringify(data)))
 }

 private mapResponse(response:Response)
 {
console.log(response.json());
return <IPeople>response.json();

 }

private handleError(error: Response) {
        // in a real world app, we may send the server to some remote logging infrastructure
        // instead of just logging it to the console
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}