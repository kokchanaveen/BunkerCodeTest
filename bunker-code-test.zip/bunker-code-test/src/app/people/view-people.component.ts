import { Component, Injectable, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {IPeople} from './ipeople';
import { PeopleService } from './people.service';

@Injectable()
@Component({
  templateUrl: './view-people.component.html',
  styleUrls: ['./view-people.component.css']
})
export class ViewPeopleComponent implements OnInit {
   pageTitle: string = 'People Detail';
   errorMessage: string;
   objPeople:IPeople;
   summary:string;
   
constructor(private route:ActivatedRoute,private router:Router,private peopleService:PeopleService){
 
}
 
back()
{
    this.router.navigate(['/AddPeople']);


}

 ngOnInit(): void {
        
this.summary=this.route.snapshot.params['firstName'] + " "+  this.route.snapshot.params['lastName'] + " " + "the color " + this.route.snapshot.params['favoriteColor']  ;

this.objPeople = {"firstName":this.route.snapshot.params['firstName'],"lastName":this.route.snapshot.params['lastName'],"favoriteColor":this.route.snapshot.params['favoriteColor'],"summary":this.summary};
      //this.peopleService.getPeople().
       // subscribe(data=>this.objPeople=data,error=>this.errorMessage=<any>error);
        //console.log(this.route.snapshot.params);
    }

}