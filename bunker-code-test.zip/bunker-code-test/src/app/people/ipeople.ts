/* Defines the people entity */
export interface IPeople {
    firstName: string;
    lastName: string;
    favoriteColor: string;
    summary:string;
   
}