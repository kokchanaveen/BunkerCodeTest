import { PeopleService } from './people.service';
import { Component, Injectable } from '@angular/core';
import {IPeople} from './ipeople';
import { Router } from '@angular/router';

@Injectable()
@Component({
  templateUrl: './add-people.component.html',
  styleUrls: ['./add-people.component.css']
})
export class AddPeopleComponent {
    title:string="Add People";
    objPeople:IPeople;
    objNewPeople:IPeople;
constructor(private peopleService:PeopleService,private router: Router){

}


addPeople(formValues)
{
   
   
  this.objPeople=<IPeople>formValues;
  this.objPeople.summary=this.objPeople.firstName + " " + this.objPeople.lastName + " " + "the color" + this.objPeople.favoriteColor  ;
  // this.peopleService.addPeople(this.objPeople).subscribe((x:IPeople)=>{this.objNewPeople=x});
  this.router.navigate(['/ViewPeople',this.objPeople.firstName,this.objPeople.lastName,this.objPeople.favoriteColor]);
 
}

cancel()
{
    this.router.navigate(['/Home']);


}

}
