import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from "app/home/home.component";
import { InstructionsComponent } from "app/instructions/instructions.component";
import { AddPeopleComponent } from 'app/people/add-people.component';
import { ViewPeopleComponent } from 'app/people/view-people.component';
//this.objPeople.firstName,this.objPeople.lastName,this.objPeople.favoriteColor
const routes: Routes = [
    { 'path': '', 'redirectTo': 'Home', 'pathMatch': 'full' },
    { 'path': 'Home', 'component': HomeComponent },
    { 'path': 'Instructions', 'component': InstructionsComponent },
    { 'path': 'AddPeople', 'component':AddPeopleComponent },
    { 'path': 'ViewPeople/:firstName/:lastName/:favoriteColor', 'component':ViewPeopleComponent },
    { 'path': '', 'redirectTo': 'Home', 'pathMatch': 'full' }
];

@NgModule({
  'imports': [RouterModule.forRoot(routes, { 'useHash': false })],
  'exports': [RouterModule]
})
export class RoutingModule { }
